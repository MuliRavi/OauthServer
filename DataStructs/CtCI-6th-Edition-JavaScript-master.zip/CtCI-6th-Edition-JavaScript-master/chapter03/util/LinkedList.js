var LinkedList = function(value) {
  this.value = value;
  this.next = null;
};

module.exports = LinkedList;