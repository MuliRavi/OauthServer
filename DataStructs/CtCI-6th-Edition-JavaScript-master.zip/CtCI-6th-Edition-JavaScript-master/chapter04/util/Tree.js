var Tree = function(value) {
  this.value = value;
  this.children = [];
};

module.exports = Tree;