// 4 000 000 000 * 8 bytes => 32 000 000 000 bytes = 32 GB

// 1) sort
// 2) iterate linearly
// 3) return number with gap
