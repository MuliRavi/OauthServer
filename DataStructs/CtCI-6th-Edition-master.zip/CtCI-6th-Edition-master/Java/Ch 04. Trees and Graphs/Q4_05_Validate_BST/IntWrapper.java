package Q4_05_Validate_BST;

public class IntWrapper {
	public IntWrapper(int m) {
		data = m;
	}
	public int data;
}
