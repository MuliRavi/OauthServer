package Q16_04_Tic_Tac_Win;

enum Piece { Empty, Red, Blue };
