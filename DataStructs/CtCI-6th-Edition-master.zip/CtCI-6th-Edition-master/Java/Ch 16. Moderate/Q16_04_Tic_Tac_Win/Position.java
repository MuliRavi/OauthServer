package Q16_04_Tic_Tac_Win;

public class Position {
	public int row, column;
	public Position(int row, int column) {
		this.row = row;
		this.column = column;
	}
}
