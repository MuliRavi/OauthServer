package Q16_10_Living_People;

public class Person {
	public int birth;
	public int death;
	public Person(int birthYear, int deathYear) {
		birth = birthYear;
		death = deathYear;
	}
}
